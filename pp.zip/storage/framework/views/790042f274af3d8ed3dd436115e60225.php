<div id="preloader">
    <div class="spinner-logo">
        <img src="<?php echo e(asset('frontend/assets/img/favicon.png')); ?>" alt="logo">
    </div>
    <div class="spinner"></div>
</div>
<!-- ./ preloader -->


<?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/preloader.blade.php ENDPATH**/ ?>