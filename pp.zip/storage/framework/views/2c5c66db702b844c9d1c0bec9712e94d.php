<?php $__env->startSection('title'); ?>
    <?php echo e('Manage General Setting'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18">Manage General Setting</h4>
    </div>

    
    <div class="row">
        <div class="col-lg-12">
            <form action="<?php echo e(route('admin.setting.general_store')); ?>" method="post" enctype="multipart/form-data"
                id="settingUpdate">
                <?php echo csrf_field(); ?>

                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Site Settings</h3>
                                    </div>

                                    <div class="card-body">
                                        <div class="row">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <?php if( !empty($settings->logo) ): ?>
                                                        <img src="<?php echo e(asset($settings->logo)); ?>" height="50px">
                                                    <?php endif; ?>

                                                    <div class="mb-3">
                                                        <label class="form-label">Site Logo
                                                            <br><small class="text-danger fw-bold"><strong>(Recommended
                                                                    Size: 180px * 60px)</strong></small>
                                                        </label>
                                                        <input type="file" class="form-control" style="height: auto;"
                                                            name="logo" placeholder="Site Logo..."
                                                            accept=".png,.jpg,.jpeg,.webp">
                                                    </div>
                                                </div>


                                                <div class="col-lg-6">
                                                    <?php if( !empty($settings->favicon) ): ?>
                                                        <img src="<?php echo e(asset($settings->favicon)); ?>" height="50px">
                                                    <?php endif; ?>

                                                    <div class="mb-3">
                                                        <label class="form-label">Favicon
                                                            <br><small class="text-danger fw-bold"><strong>( Recommended
                                                                    Size: 200px * 200px )</strong></small>
                                                        </label>
                                                        <input type="file" class="form-control" style="height: auto;"
                                                            name="favicon" placeholder="Favicon..."
                                                            accept=".png,.jpg,.jpeg,.webp">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row align-items-end">
                                                <div class="col-lg-6">
                                                    <?php if( !empty($settings->profile_photo) ): ?>
                                                        <img src="<?php echo e(asset($settings->profile_photo)); ?>" height="50px">
                                                    <?php endif; ?>
    
                                                    <div class="mb-3">
                                                        <label class="form-label">Profile Photo
                                                            <br><small class="text-danger fw-bold"><strong>(Recommended Size: 180px * 60px)</strong></small>
                                                        </label>
                                                        <input type="file" class="form-control" style="height: auto;"
                                                            name="profile_photo" placeholder="Profile Photo..."
                                                            accept=".png,.jpg,.jpeg,.webp">
                                                    </div>
                                                </div>
    
                                                <div class="col-lg-6">
                                                    <?php if( !empty($settings->pdf) ): ?>
                                                        <a href="<?php echo e(asset($settings->pdf)); ?>" target="__blank">
                                                            <img src="<?php echo e(asset('public/adminpanel/images/pdf_file.png')); ?>" height="50px">
                                                        </a>
                                                    <?php endif; ?>
    
                                                    <div class="mb-3">
                                                        <label class="form-label">Resume / CV
                                                            <br><small class="text-danger fw-bold"><strong>(Recommended Size: PDF)</strong></small>
                                                        </label>
                                                        <input type="file" class="form-control" style="height: auto;"
                                                            name="pdf" accept=".pdf">
                                                    </div>
                                                </div>

                                                <div class="col-lg-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Site Name</label>
                                                        <input type="text" class="form-control" name="site_name" placeholder="Site Name..."
                                                        required="" value="<?php echo e($settings->site_name ?? ""); ?>">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Description</label>
                                                        <textarea class="form-control" name="description" rows="3"
                                                            style="height: 120px !important;"><?php echo e($settings->description ?? ""); ?>

                                                        </textarea>
                                                    </div>
                                                </div>

                                                <div class="col-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Street Address</label>
                                                        <textarea class="form-control" name="address" rows="3" placeholder="Street Address...."
                                                            style="height: 120px !important;"><?php echo e($settings->address ?? ""); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Google Map</label>
                                                        <textarea class="form-control" name="google_map" rows="3" placeholder="Google Map...."
                                                            style="height: 120px !important;"><?php echo e($settings->google_map ?? ""); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Social URL</h3>
                                    </div>
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label
                                                        class="form-label"><?php echo e(__('Facebook URL')); ?></label>
                                                    <input type="url" class="form-control"
                                                        name="facebook_url"
                                                        value="<?php echo e($settings->facebook_url ?? ""); ?>"
                                                        placeholder="<?php echo e(__('Facebook URL')); ?>...">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label"><?php echo e(__('Twitter Url')); ?></label>
                                                    <input type="url" class="form-control"
                                                        name="twitter_url"
                                                        value="<?php echo e($settings->twitter_url ?? ""); ?>"
                                                        placeholder="<?php echo e(__('Twitter Url')); ?>...">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label
                                                        class="form-label">Instagram url</label>
                                                    <input type="url" class="form-control"
                                                        name="instagram_url"
                                                        value="<?php echo e($settings->instagram_url ?? ""); ?>"
                                                        placeholder="Instagram url...">
                                                </div>
                                            </div>
                                            
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label
                                                        class="form-label"><?php echo e(__('Linkedin url')); ?></label>
                                                    <input type="url" class="form-control"
                                                        name="linkedin_url"
                                                        value="<?php echo e($settings->linkedin_url ?? ""); ?>"
                                                        placeholder="<?php echo e(__('Linkedin url')); ?>...">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label
                                                        class="form-label"><?php echo e(__('Github url')); ?></label>
                                                    <input type="url" class="form-control"
                                                        name="github_url"
                                                        value="<?php echo e($settings->github_url ?? ""); ?>"
                                                        placeholder="<?php echo e(__('Github url')); ?>...">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label
                                                        class="form-label"><?php echo e(__('Pinterest url')); ?></label>
                                                    <input type="url" class="form-control"
                                                        name="pinterest_url"
                                                        value="<?php echo e($settings->pinterest_url ?? ""); ?>"
                                                        placeholder="<?php echo e(__('Pinterest url')); ?>...">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">About Me</h3>
                                    </div>

                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="mb-3">
                                                    <label for="multiple_name" class="form-label">Multiple Name <span
                                                            class="text-danger">*</span></label>
                                                    <input name="multiple_name" id="multiple_name" type="text" value="<?php echo e($settings->multiple_name ?? ""); ?>" class="form-control multiple_name" 
                                                        required>
                                                </div>
                                            </div>

                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">First Skill</label>
                                                    <input type="text" name="first_skill" class="form-control"
                                                        value="<?php echo e($settings->first_skill ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Second Skill</label>
                                                    <input type="text" name="second_skill" class="form-control"
                                                        value="<?php echo e($settings->second_skill ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Location</label>
                                                    <input type="text" name="location" class="form-control"
                                                        value="<?php echo e($settings->location ?? ""); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">Counter Section</h3>
                                    </div>

                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Experirnce Year</label>
                                                    <input type="number" name="exp_year" class="form-control"
                                                        value="<?php echo e($settings->exp_year ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Experirnce Name</label>
                                                    <input type="text" name="exp_name" class="form-control"
                                                        value="<?php echo e($settings->exp_name ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Project Count</label>
                                                    <input type="number" name="project_count" class="form-control"
                                                        value="<?php echo e($settings->project_count ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Project Name</label>
                                                    <input type="text" name="project_name" class="form-control"
                                                        value="<?php echo e($settings->project_name ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Client Count</label>
                                                    <input type="number" name="client_count" class="form-control"
                                                        value="<?php echo e($settings->client_count ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Client Name</label>
                                                    <input type="text" name="client_name" class="form-control"
                                                        value="<?php echo e($settings->client_name ?? ""); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3 class="card-title">General Settings</h3>
                                    </div>

                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Email</label>
                                                    <input type="email" name="email" class="form-control"
                                                        value="<?php echo e($settings->email ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Email Optional</label>
                                                    <input type="email" name="email_optional" class="form-control"
                                                        value="<?php echo e($settings->email_optional ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Phone Number</label>
                                                    <input type="text" name="phone" class="form-control"
                                                        value="<?php echo e($settings->phone ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">(optional) Phone Number</label>
                                                    <input type="text" name="phone_optional" class="form-control"
                                                        value="<?php echo e($settings->phone_optional ?? ""); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6">
                                                <div class="mb-3">
                                                    <label class="form-label">Copyright</label>
                                                    <input type="text" name="copyright" class="form-control"
                                                        value="<?php echo e($settings->copyright ?? ""); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <button type="submit" class="btn btn-success" id="updateButton">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/choices.js@9.0.1/public/assets/scripts/choices.min.js"></script>

    <script>
        $(document).ready(function() {
            // Choice.js plugin
            const product_tags = new Choices('.multiple_name', {
                removeItems: true,
                duplicateItemsAllowed: false,
                removeItemButton: true,
                delimiter: ',',
            });
        })

        const form = document.getElementById("settingUpdate");
        const submitButton = form.querySelector("button[type='submit']");

        form.addEventListener("submit", function() {

            $("#updateButton").html(`
            <span id="">
                <span class="spinner-border spinner-border-sm text-white" role="status" aria-hidden="true"></span>
                Updating Setting...
            </span>
        `);

            submitButton.disabled = true;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal_portfolio\resources\views/admin/pages/settings/general_setting.blade.php ENDPATH**/ ?>