
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery-migrate-3.4.0.min.js')); ?>"></script>

    <!-- plugins -->
    <script src="<?php echo e(asset('public/frontend/assets/js/plugins.js')); ?>"></script>

    <!-- custom scripts -->
    <script src="<?php echo e(asset('public/frontend/assets/js/scripts.js')); ?>"></script>

    <!-- toaster Js plugins  -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


    <?php echo $__env->yieldPushContent('add-js'); ?>

    <?php echo Toastr::message(); ?>


    <script>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo $error; ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script><?php /**PATH C:\xampp\htdocs\personal_portfolio\resources\views/frontend/include/js.blade.php ENDPATH**/ ?>