

<?php $__env->startPush('add-title'); ?>
    Home
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body-content'); ?>

<!-- ==================== Start Resume ==================== -->

<section class="resume section-padding">
    <div class="container with-pad">

        <?php if( $faq->is_active == 1 ): ?>
            <div class="sec-head mb-80">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="d-inline-block">
                            <div class="sub-title-icon d-flex align-items-center">
                                <span class="icon pe-7s-note2"></span>
                                <h6><?php echo e($faq->title); ?></h6>
                            </div>
                        </div>
                        <h3><?php echo e($faq->subtitle); ?></h3>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row">
           <div class="col-lg-10 offset-lg-1">
            <div class="accordion" id="accordionExample">
                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                            <button class="accordion-button <?php echo e($index === 0 ? '' : 'collapsed'); ?>" 
                                    type="button" 
                                    data-bs-toggle="collapse" 
                                    data-bs-target="#collapse<?php echo e($index); ?>" 
                                    aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>" 
                                    aria-controls="collapse<?php echo e($index); ?>">
                                <?php echo e($row->question); ?>

                            </button>
                        </h2>
            
                        <div id="collapse<?php echo e($index); ?>" 
                            class="accordion-collapse collapse <?php echo e($index === 0 ? 'show' : ''); ?>" 
                            aria-labelledby="heading<?php echo e($index); ?>" 
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <?php echo e($row->answer); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           </div>
        </div>
    </div>
</section>

<!-- ==================== End Resume ==================== -->

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/frontend/pages/faq.blade.php ENDPATH**/ ?>