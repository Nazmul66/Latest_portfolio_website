<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect">
                        <i class="bx bx-home-circle"></i>
                        <span key="t-dashboard">Dashboard</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('admin.contact.index')); ?>" class="waves-effect">
                        <i class="bx bxs-user-detail"></i>
                        <span key="t-contacts">Contacts</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.faq.index')); ?>" class="waves-effect">
                        <i class="mdi mdi-comment-question-outline"></i>
                        <span key="t-faqs">FAQ</span>
                    </a>
                </li>

                
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-code-alt"></i>
                        <span key="t-section">All Blogs</span>
                    </a>
                    <ul class="sub-menu mm-collapse" aria-expanded="false">
                        <li class="<?php echo $__env->yieldContent('blog_category'); ?>">
                            <a href="<?php echo e(route('admin.blogs_category.index')); ?>" class="waves-effect">
                                <span key="t-contacts">Blog Category</span>
                            </a>
                        </li>

                        <li class="<?php echo $__env->yieldContent('blogs'); ?>">
                            <a href="<?php echo e(route('admin.blogs.index')); ?>" class="waves-effect">
                                <span key="t-contacts">Blogs Section</span>
                            </a>
                        </li>
                    </ul>
                </li>
                
                <li class="<?php echo $__env->yieldContent('testimonial'); ?>">
                    <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="waves-effect">
                        <i class='bx bx-message-rounded-detail'></i>
                        <span key="t-brands">Testimonial</span>
                    </a>
                </li>

                <li class="<?php echo $__env->yieldContent('about_us'); ?>">
                    <a href="<?php echo e(route('admin.about_us.index')); ?>" class="waves-effect">
                        <i class='bx bx-message-dots'></i>
                        <span key="t-brands">About Us</span>
                    </a>
                </li>

                <li class="<?php echo $__env->yieldContent('portfolio'); ?>">
                    <a href="<?php echo e(route('admin.portfolio.index')); ?>" class="waves-effect">
                        <i class='bx bx-layer-plus'></i>
                        <span key="t-brands">Portfolio</span>
                    </a>
                </li>

                <li class="<?php echo $__env->yieldContent('skill'); ?>">
                    <a href="<?php echo e(route('admin.skills.index')); ?>" class="waves-effect">
                        <i class='bx bx-pen'></i>
                        <span key="t-brands">Skills</span>
                    </a>
                </li>

                <li class="<?php echo $__env->yieldContent('experience'); ?>">
                    <a href="<?php echo e(route('admin.experience.index')); ?>" class="waves-effect">
                        <i class='bx bx-archive'></i>
                        <span key="t-brands">Experience</span>
                    </a>
                </li>

                <li class="<?php echo $__env->yieldContent('service'); ?>">
                    <a href="<?php echo e(route('admin.service.index')); ?>" class="waves-effect">
                        <i class='bx bx-bar-chart-square'></i>
                        <span key="t-brands">Services</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.brand.index')); ?>" class="waves-effect">
                        <i class="bx bx-cube-alt"></i>
                        <span key="t-brands">Brand</span>
                    </a>
                </li>

                <li class="<?php echo $__env->yieldContent('cpage_list'); ?>">
                    <a href="<?php echo e(route('admin.cpage.index')); ?>" class="waves-effect">
                        <i class='bx bx-window-alt'></i>
                        <span key="t-section">Custom Pages</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('admin.setting.general.setting')); ?>" class="waves-effect">
                        <i class='bx bx-cog'></i>
                        <span key="t-section">settings</span>
                    </a>
                </li>

                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                            <button type="submit" style="border: none;
                            background: transparent;">
                            <i class="bx bx-power-off align-middle me-1 text-danger"></i> 
                            <span key="t-logout">Logout</span>
                        </button>    
                    </form>
                </li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>