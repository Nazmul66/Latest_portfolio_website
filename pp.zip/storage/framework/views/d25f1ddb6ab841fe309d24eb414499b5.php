<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
        
        <div class="">
            <a href="<?php echo e(route('admin.course_module.index', $course_module_id)); ?>" class="btn btn-primary waves-effect waves-light">Back to course module</a>
            <a href="<?php echo e(route('admin.course_video.create', $course_module_id)); ?>" class="btn btn-primary waves-effect waves-light">Add New</a>
        </div>
    </div>


    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered mb-0 table-hover" id="datatables">
                    <thead>
                        <tr>
                            <th>#SL.</th>
                            <th>Course Module</th>
                            <th>Video Title</th>
                            <th>Video Timer</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $course_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($item->course_module_name); ?></td>
                            <td><?php echo e($item->video_title); ?></td>
                            <td><?php echo e($item->video_timer); ?></td>
                            <td>
                                <?php if($item->status == 1): ?>
                                    <span class="text-success">Active</span>
                                <?php else: ?>
                                    <span class="text-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-primary waves-effect waves-light dropdown-toggle" type="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        Actions
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="javascript:void();" data-bs-toggle="modal" data-bs-target="#view_modal<?php echo e($item->id); ?>" class="dropdown-item" style="font-size: 16px;"><i
                                                class='fas fa-eye text-info'></i> View</a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('admin.course_video.edit', [$course_module_id, $item->id])); ?>" class="dropdown-item" style="font-size: 16px;"><i
                                                    class='bx bxs-edit text-info'></i> Edit</a>
                                        </li>

                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.course_video.delete', $item->id)); ?>" style="font-size: 16px;"
                                                id="deleteData"><i
                                                    class='bx bxs-trash text-danger'></i> Delete</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>

                            <!-- View Modal -->
                            <div class="modal fade" id="view_modal<?php echo e($item->id); ?>" tabindex="-1"
                                aria-labelledby="edit_lLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">View Course Video List</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>

                                        <div class="modal-body">
                                            <div class="message_content">
                                                <label>Course Module Name : </label>
                                                <span class="text-dark"><?php echo e($item->course_module_name); ?></span>
                                            </div>

                                            <div class="message_content">
                                                <label>Video Title : </label>
                                                <span class="text-dark"><?php echo e($item->video_title); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Video Timer : </label>
                                                <span class="text-dark"><?php echo e($item->video_timer); ?></span>
                                            </div>
                                            
                                            <div class="view_modal_content">
                                                <label>Date : </label>
                                                <span class="text-dark"><?php echo e(date('d M Y', strtotime($item->created_at))); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Status : </label>
                                                <?php if($item->status == 1): ?>
                                                    <span class="text-success">Active</span>
                                                <?php else: ?>
                                                    <span class="text-danger">Inactive</span>
                                                <?php endif; ?>
                                            </div>

                                            <div class="view_modal_content">
                                                <span class="text-dark"><?php echo $item->video_link; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>

    <script>
        let table = new DataTable('#datatables', {
            responsive: true
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/course_video/index.blade.php ENDPATH**/ ?>