<div id="scrollup">
    <button id="scroll-top" class="scroll-to-top">
        <i class="fa-solid fa-arrow-up"></i>
    </button>
</div><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/scroll_to_top.blade.php ENDPATH**/ ?>