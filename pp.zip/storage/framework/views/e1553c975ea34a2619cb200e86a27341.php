<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- Metas -->
    <?php echo $__env->make('frontend.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</head>

<body>

    <!-- ==================== Start Loading ==================== -->
        <?php echo $__env->make('frontend.include.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ==================== End Loading ==================== -->


    <!-- ==================== Start progress-scroll-button ==================== -->
        <?php echo $__env->make('frontend.include.scroll_to_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ==================== End progress-scroll-button ==================== -->


    <!-- ==================== Start Navbar ==================== -->
        <?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ==================== End Navbar ==================== -->


    <main class="pt-80">
        <!-- ==================== Start Hero ==================== -->
            <?php echo $__env->yieldContent('body-content'); ?>
        <!-- ==================== End Hero ==================== -->
    </main>


    <!-- ==================== Start Footer ==================== -->
       <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ==================== End Footer ==================== -->


    <!-- jQuery -->
    <?php echo $__env->make('frontend.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\personal_portfolio\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>