

<?php $__env->startPush('add-title'); ?>
    Home
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body-content'); ?>

 <!-- ==================== Start About ==================== -->

 <section class="about section-padding">
    <div class="container with-pad">
        <div class="row lg-marg">
            <div class="col-lg-5 valign">
                <div class="profile-img">
                    <div class="img">
                        <img src="<?php echo e(asset($about_us->image)); ?>" alt="">
                    </div>

                    
                    
                    
                </div>
            </div>
            <div class="col-lg-7 valign">
                <div class="cont">
                    <div class="sub-title-icon d-flex align-items-center">
                        <span class="icon pe-7s-gleam"></span>
                        <h6><?php echo e($about_us->title); ?></h6>
                    </div>
                    <div class="text">
                        <h4 class="mb-30"><?php echo e($about_us->sub_title); ?></h4>


                        <div class="about_desc feat mt-30">

                            <?php echo $about_us->description; ?>

                            
                            
                            
                        </div>

                        <div class="info mt-50">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="item d-flex align-items-center sm-mb30">
                                        <div class="mr-15">
                                            <span class="icon pe-7s-mail"></span>
                                        </div>
                                        <div>
                                            <span class="opacity-7 mb-5">Email Us</span>
                                            <h6>
                                                <?php if( !empty(getSetting()->email) ): ?>
                                                    <a href="mailto:<?php echo e(getSetting()->email); ?>"><?php echo e(getSetting()->email); ?></a>
                                                <?php else: ?>
                                                    <a href="mailto:<?php echo e(getSetting()->email); ?>"><?php echo e(getSetting()->email_optional); ?></a>
                                                <?php endif; ?>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="item d-flex align-items-center">
                                        <div class="mr-15">
                                            <span class="icon pe-7s-call"></span>
                                        </div>
                                        <div>
                                            <span class="opacity-7 mb-5">Call Us</span>
                                            <h6>
                                                <?php if( !empty(getSetting()->phone) ): ?>
                                                    <a href="tel:<?php echo e(getSetting()->phone); ?>"><?php echo e(getSetting()->phone); ?></a>
                                                <?php else: ?>
                                                    <a href="tel:<?php echo e(getSetting()->phone_optional); ?>"><?php echo e(getSetting()->phone_optional); ?></a>
                                                <?php endif; ?>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==================== End About ==================== -->



<!-- ==================== Start Skills ==================== -->

<section class="skills section-padding pt-0">
    <div class="container with-pad">

        <?php if( $skill->is_active == 1 ): ?>
            <div class="sec-head mb-80">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="sub-title-icon d-flex align-items-center">
                            <span class="icon pe-7s-gym"></span>
                            <h6><?php echo e($skill->title); ?></h6>
                        </div>
                        <h3><?php echo e($skill->subtitle); ?></h3>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="row">

            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="item mb-30">
                        <div class="d-flex align-items-center mb-30">
                            <div class="mr-30">
                                <div class="img icon-img-40">
                                    <img src="<?php echo e(asset($row->image)); ?>" alt="">
                                </div>
                            </div>
                            <div>
                                <h6 class="fz-18"><?php echo e($row->name); ?></h6>
                            </div>
                        </div>
                        <div class="skill-progress">
                            <span class="progres" data-value="<?php echo e($row->percentage); ?>%"></span>
                        </div>
                        <span class="value"><?php echo e($row->percentage); ?>%</span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </div>
    </div>
</section>

<!-- ==================== End Skills ==================== -->



<!-- ==================== Start Resume ==================== -->

<section class="resume section-padding pt-0">
    <div class="container with-pad">

        <?php if( $experience->is_active == 1 ): ?>
            <div class="sec-head mb-80">
                <div class="row justify-content-center">
                    <div class="col-lg-6 text-center">
                        <div class="d-inline-block">
                            <div class="sub-title-icon d-flex align-items-center">
                                <span class="icon pe-7s-note2"></span>
                                <h6><?php echo e($experience->title); ?></h6>
                            </div>
                        </div>
                        <h3><?php echo e($experience->subtitle); ?></h3>
                    </div>
                </div>
            </div>
        <?php endif; ?>


        <div>
            <div class="resume-swiper" data-carousel="swiper" data-space="50" data-speed="1000">
                <div id="content-carousel-container-unq-resume" class="swiper-container"
                    data-swiper="container">
                    <div class="swiper-wrapper">

                        <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="item text-center">
                                    <h6 class="main-color date fz-15 mb-60"><?php echo e($row->year); ?></h6>
                                    <h5><?php echo e($row->designation); ?></h5>
                                    <span class="opacity-8 fw-500 mt-10"><?php echo e($row->company_name); ?></span>
                                    <p class="fz-13 mt-15"><?php echo e($row->short_desc); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==================== End Resume ==================== -->


<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>