<?php $__env->startSection('cpage_list', 'mm-active'); ?>

<?php $__env->startSection('title'); ?> <?php echo e($data['title'] ?? ''); ?> <?php $__env->stopSection(); ?>

<?php
    $row = $data['row'];
?>

<?php $__env->startPush('style'); ?>
    <style>
        td {
            width: 0;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18">View <?php echo e($row->title); ?> pages</h4>
        <a href="<?php echo e(route('admin.cpage.index')); ?>" class="btn btn-primary waves-effect waves-light">Back</a>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <table class="table">
                    <tr>
                        <td style="width:10%;"><strong>Page Name :</strong></td>
                        <td><?php echo e($row->title); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Page Slug :</strong></td>
                        <td><?php echo e($row->url_slug); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status :</strong></td>
                        <td>
                            <?php if($row->is_active == 1): ?>
                                <span class="text-success">Active</span>
                            <?php else: ?>
                                <span class="text-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <strong class="mb-3 d-block" style="font-size: 20px;">Description :</strong>
                            <br>
                            <?php echo $row->body; ?>

                        </td>
                    </tr>
                </table>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/admin/pages/custom-page/view.blade.php ENDPATH**/ ?>