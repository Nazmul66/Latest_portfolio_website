

<?php $__env->startPush('add-title'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('body-content'); ?>

<!-- header-area-start -->
<?php echo $__env->make('frontend.include.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.include.breadcrumb', ['title' => 'Course Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ./ page-header -->

<section class="course-details pt-120 pb-120">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-lg-12">
                <div class="course-details-content">
                    <div class="course-details-img">
                        <img src="<?php echo e(asset($course->image)); ?>" alt="course">
                    </div>
                    
                    <div class="details-inner">
                        

                        <h2 class="title"><?php echo e($course->title); ?></h2>
                        <ul class="course-details-list">
                            <li><img src="<?php echo e(asset('frontend/assets/img/service/course-details-author.png')); ?>" alt="author"><span>Instructor:</span> <?php echo e($course->name); ?></li>
                            

                            <li><i class="fa-light fa-calendar"></i><?php echo e(date('d M, Y', strtotime($course->created_at))); ?></li>

                            
                        </ul>
                    </div>

                    <div class="course-details-tab">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true"><i class="fa-sharp fa-regular fa-bookmark"></i>Overview</button>
                            </li>

                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false"><i class='bx bx-purchase-tag-alt' style="font-size: 24px;"></i>Curriculam</button>
                            </li>

                            

                            
                        </ul>



                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="tab-overview">

                                    <?php echo $course->description; ?>


                                    
                                </div>
                            </div>

                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="curriculam-area">
                                    <div class="accordion" id="accordionExample">

                                        <?php $__currentLoopData = $course_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="accordion-item">
                                                <h2 class="accordion-header" id="heading<?php echo e($s + 1); ?>">
                                                    <button class="accordion-button <?php echo e($loop->first ? '' : 'collapsed'); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($s + 1); ?>" aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($s + 1); ?>">
                                                        <?php echo e($item->name); ?>

                                                    </button>
                                                </h2>
                                                <div id="collapse<?php echo e($s + 1); ?>" class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>" aria-labelledby="heading<?php echo e($s + 1); ?>" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <ul class="curri-list">
                                                            <?php
                                                                $course_videos = App\Models\CourseVideo::where('course_module_id', $item->id)->where('status', 1)->get();
                                                            ?>

                                                            <?php $__currentLoopData = $course_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li>
                                                                    <span>
                                                                        <i class='bx bx-video' style="font-size: 24px;"></i>  <?php echo e($row->video_title); ?>

                                                                    </span> 

                                                                    <span><?php echo e($row->video_timer); ?> <i class='bx bx-time-five' style="font-size: 24px;"></i>
                                                                    </span>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                            
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-xl-3 col-lg-12">
                <div class="course-sidebar price-box">
                    
                    <h4 class="price">$<?php echo e(number_format($course->price, 2)); ?></h4>

                    <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                         
                        <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">

                        <button type="submit" class="ed-primary-btn">Add to Cart</button>
                    </form>
                    
                </div>

                <div class="course-sidebar sticky-widget">
                    <h4 class="sidebar-title">Course Information</h4>
                    <ul class="course-sidebar-list">
                        <li><i class='bx bx-home' style="font-size: 20px;"></i>Instructor: <span>Kevin Perry</span></li>
                        <li><i class='bx bx-book-bookmark' style="font-size: 20px;"></i>Lessons: <span><?php echo e($course->lesson); ?></span></li>
                        <li><i class='bx bx-time-five' style="font-size: 20px;"></i>Duration: <span><?php echo e($course->duration); ?></span></li>
                        <li><i class='bx bx-purchase-tag-alt' style="font-size: 20px;"></i>Course level: <span><?php echo e($course->course_level); ?></span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/pages/course_details.blade.php ENDPATH**/ ?>