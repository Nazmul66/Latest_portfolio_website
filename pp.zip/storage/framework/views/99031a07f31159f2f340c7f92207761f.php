

<?php $__env->startPush('add-title'); ?>
    Home
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body-content'); ?>

    <!-- ==================== Start Services ==================== -->

    <section class="services section-padding">
        <div class="container with-pad">

            <?php if( $service->is_active == 1 ): ?>
                <div class="sec-head mb-80">
                    <div class="row justify-content-center">
                        <div class="col-lg-8 text-center">
                            <div class="d-inline-block">
                                <div class="sub-title-icon d-flex align-items-center">
                                    <span class="icon pe-7s-bell"></span>
                                    <h6><?php echo e($service->title); ?></h6>
                                </div>
                            </div>
                            <h3><?php echo e($service->subtitle); ?></h3>
                        </div>
                    </div>
                </div>
            <?php endif; ?>


            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="item mb-30">
                            <div class="cont">
                                <div class="d-flex align-items-center mb-30">
                                    <div>
                                        <span class="icon-img-50 mr-40">
                                            <img src="<?php echo e(asset($row->image)); ?>" alt="">
                                        </span>
                                    </div>
                                    <div>
                                        <span class="opacity-7 fz-13 mb-5"><?php echo e($row->total_project); ?> Projects</span>
                                        <h5 class="fz-20"><?php echo e($row->title); ?></h5>
                                    </div>
                                </div>
                                <p><?php echo e($row->short_desc); ?></p>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                
            </div>
        </div>
    </section>

    <!-- ==================== End Services ==================== -->



    <!-- ==================== Start Pricing ==================== -->

    

    <!-- ==================== End Pricing ==================== -->



    <!-- ==================== Start Brands ==================== -->

    <section class="brands section-padding pt-0">
        <div class="container with-pad">
            <div class="text-center">
                <h6><span class="main-color">Worldwide client satisfaction</span> trusted us </h6>
            </div>

            <div class="row">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 col-md-3 col-lg-2 col-6">
                        <div class="item">
                            <div class="img icon-img-100">
                                <a href="<?php echo e(asset($row->image)); ?>">
                                    <img src="<?php echo e(asset($row->image)); ?>" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                
            </div>
        </div>
    </section>

    <!-- ==================== End Brands ==================== -->

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/frontend/pages/service.blade.php ENDPATH**/ ?>