

<?php $__env->startPush('add-title'); ?>
    
<?php $__env->stopPush(); ?>


<?php $__env->startSection('body-content'); ?>

<!-- header-area-start -->
<?php echo $__env->make('frontend.include.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="error-section pt-120 pb-120">
    <div class="container">
        <div class="error-content text-center">
            <img src="<?php echo e(asset('frontend/assets/img/images/error-img.png')); ?>" alt="img">
            <h2 class="text">404 - Page Not Found</h2>
            <p class="mb-20 mt-20">The page you are looking for does not exist</p>
            <a class="ed-primary-btn" href="index.html">Back To Home Page</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/errors/404.blade.php ENDPATH**/ ?>