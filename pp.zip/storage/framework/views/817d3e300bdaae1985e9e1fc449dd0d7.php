<nav class="navbar navbar-chang navbar-expand-lg">
    <div class="container position-re">
        <div class="row">
            <div class="col-lg-3 col-6 order1">
                <div class="bord">
                    <!-- Logo -->
                    <a class="logo icon-img-70" href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset(getSetting()->logo)); ?>" alt="logo">
                    </a>
                </div>
            </div>
            <div class="col-lg-6 order3">
                <div class="bg">
                    <!-- navbar links -->
                    <div class="full-width">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('home')); ?>"><span
                                        class="rolling-text">Home</span></a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('about')); ?>"><span
                                        class="rolling-text">About</span></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('service')); ?>"><span
                                        class="rolling-text">Services</span></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('portfolio')); ?>"><span
                                        class="rolling-text">Portfolio</span></a>
                            </li>

                            

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('faq')); ?>"><span
                                        class="rolling-text">Faq</span></a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('contact')); ?>"><span
                                        class="rolling-text">Contact</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6 order2">
                <div class="bord d-flex justify-content-end">
                    <ul class="social d-flex rest">
                        <?php if( !empty(getSetting()->github_url) ): ?>
                            <li>
                                <a href="<?php echo e(getSetting()->github_url); ?>"><i class="fab fa-github"></i></a>
                            </li>
                        <?php endif; ?> 

                        <?php if( !empty(getSetting()->facebook_url) ): ?>
                            <li>
                                <a href="<?php echo e(getSetting()->facebook_url); ?>"><i class="fab fa-facebook-f"></i></a>
                            </li> 
                        <?php endif; ?>

                        <?php if( !empty(getSetting()->linkedin_url) ): ?>
                            <li>
                                <a href="<?php echo e(getSetting()->linkedin_url); ?>"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                        <?php endif; ?>

                        <?php if( !empty(getSetting()->pinterest_url) ): ?>
                            <li>
                                <a href="<?php echo e(getSetting()->pinterest_url); ?>"><i class="fab fa-pinterest"></i></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <button class="navbar-toggler" type="button">
                        <span class="icon-bar"><i class="fas fa-bars"></i></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</nav><?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>