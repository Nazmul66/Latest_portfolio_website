

<?php $__env->startPush('add-title'); ?>
    Home
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body-content'); ?>

 <!-- ==================== Start Contact ==================== -->

 <section class="contact section-padding">
    <div class="container">
        <div class="sec-head mb-80">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <div class="d-inline-block">
                        <div class="sub-title-icon d-flex align-items-center">
                            <span class="icon pe-7s-map-marker"></span>
                            <h6>Contact Us</h6>
                        </div>
                    </div>
                    <h3>Let's Get in Touch!</h3>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="google-map mb-80">
                    <div id="gmap_canvas">
                        <?php echo getSetting()->google_map; ?>

                    </div>

                </div>
            </div>
            <div class="col-lg-5 valign">
                <div class="info full-width md-mb80">
                    <div class="item mb-30 d-flex align-items-center">
                        <div class="mr-15">
                            <span class="icon fz-40 main-color pe-7s-call"></span>
                        </div>
                        <div class="mr-10">
                            <h6 class="opacity-7">Phone</h6>
                        </div>
                        <div class="ml-auto">
                            <h4>
                                <?php if( !empty(getSetting()->phone) ): ?>
                                    <a href="tel:<?php echo e(getSetting()->phone); ?>"><?php echo e(getSetting()->phone); ?></a>
                                <?php else: ?>
                                    <a href="tel:<?php echo e(getSetting()->phone_optional); ?>"><?php echo e(getSetting()->phone_optional); ?></a>
                                <?php endif; ?>
                            </h4>
                        </div>
                    </div>
                    <div class="item mb-30 d-flex align-items-center">
                        <div class="mr-15">
                            <span class="icon fz-40 main-color pe-7s-mail"></span>
                        </div>
                        <div class="mr-10">
                            <h6 class="opacity-7">Email</h6>
                        </div>
                        <div class="ml-auto">
                            <h4>
                                <?php if( !empty(getSetting()->email) ): ?>
                                    <a href="mailto:<?php echo e(getSetting()->email); ?>"><?php echo e(getSetting()->email); ?></a>
                                <?php else: ?>
                                    <a href="mailto:<?php echo e(getSetting()->email); ?>"><?php echo e(getSetting()->email_optional); ?></a>
                                <?php endif; ?>
                            </h4>
                        </div>
                    </div>
                    <div class="item d-flex align-items-center">
                        <div class="mr-15">
                            <span class="icon fz-40 main-color pe-7s-map-marker"></span>
                        </div>
                        <div class="mr-10">
                            <h6 class="opacity-7">Address</h6>
                        </div>
                        <div class="ml-auto">
                            <h4><?php echo e(getSetting()->address); ?></h4>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-7 valign">
                <div class="full-width">
                    <form method="POST" action="<?php echo e(route('contact.post')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="messages"></div>
                        <div class="controls row">
                            <div class="col-lg-6">
                                <div class="form-group mb-30">
                                    <label>Your Name</label>
                                    <input id="form_name" type="text" name="name" required="required">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group mb-30">
                                    <label>Your Email</label>
                                    <input id="form_email" type="email" name="email" required="required">
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label>Your Message</label>
                                    <textarea id="form_message" name="message" required="required"></textarea>
                                </div>

                                <div class="mt-30">
                                    <button type="submit">
                                        <span class="text">Send A Message</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==================== End Contact ==================== -->

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\personal_portfolio\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>