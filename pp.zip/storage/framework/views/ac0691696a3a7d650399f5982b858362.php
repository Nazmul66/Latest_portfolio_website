<?php $__env->startSection('title'); ?>
    <?php echo e('Manage All Pages'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap5-toggle@5.1.1/css/bootstrap5-toggle.min.css" rel="stylesheet">
    <style>

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18">Manage All Pages</h4>
        <a href="<?php echo e(route('admin.cpage.create')); ?>" class="btn btn-primary waves-effect waves-light">Add New</a>
    </div>


    


    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered mb-0 table-hover" id="datatables">
                    <thead>
                        <tr>
                            <th>#SL.</th>
                            <th>Page Name</th>
                            <th>Status</th>
                            
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key + 1); ?></th>

                                <td><?php echo e($row->title); ?></td>

                                <td>
                                    <input type="checkbox" class="status-toggle" data-id="<?php echo e($row->id); ?>"
                                        data-toggle="toggle" data-onlabel="Active" data-offlabel="Inactive"
                                        data-onstyle="success" data-offstyle="danger"
                                        <?php echo e($row->is_active == 1 ? 'checked' : ''); ?>>
                                    
                                </td>

                                

                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-primary waves-effect waves-light dropdown-toggle"
                                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Actions
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a href="<?php echo e(route('admin.cpage.view', $row->id)); ?>" class="dropdown-item"
                                                    style="font-size: 16px;"><i class="fas fa-eye"></i> View</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('admin.cpage.edit', $row->id)); ?>" class="dropdown-item"
                                                    style="font-size: 16px;"><i class='bx bxs-edit text-info'></i> Edit</a>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>



    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap5-toggle@5.1.1/js/bootstrap5-toggle.ecmas.min.js"></script>
    <script>
        let table = new DataTable('#datatables', {
            responsive: true
        });

        $(document).ready(function() {
            $('.status-toggle').change(function() {
                let isChecked = $(this).prop('checked') ? 1 : 0;
                let rowId = $(this).data('id');
                console.log(rowId);


                $.ajax({
                    url: "<?php echo e(route('admin.cpage.toggleStatus')); ?>",
                    type: "POST",
                    data: {
                        id: rowId,
                        is_active: isChecked,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        toastr.success(response.message);
                    },
                    error: function() {
                        toastr.error('An error occurred while updating the status.');
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal_portfolio\resources\views/admin/pages/custom-page/index.blade.php ENDPATH**/ ?>