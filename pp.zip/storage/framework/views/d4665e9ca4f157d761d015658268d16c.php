<footer class="footer-section pt-120" data-background="<?php echo e(asset('frontend/assets/img/bg-img/footer-bg.png')); ?>">
    <div class="footer-top-wrap">
        <div class="container">
            

            <div class="row footer-wrap">
                <div class="col-lg-3 col-md-6">
                    <div class="footer-widget">
                        <h3 class="widget-header">Get in touch!</h3>
                        <p class="mb-30"><?php echo e(getSetting()->address ?? ""); ?></p>
                        <div class="footer-contact">
                            <span class="number">
                                <i class='bx bx-phone-call' style="font-size: 24px;"></i><a href="tel:<?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?>"><?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?></a>
                            </span>
                            <a href="mailto:info@company.com" class="mail">info@company.com</a>
                        </div>
                        <ul class="footer-social">
                            <?php if( !empty(getSetting()->facebook_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->facebook_url)); ?>">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if( !empty(getSetting()->instagram_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->instagram_url)); ?>">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if( !empty(getSetting()->twitter_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->twitter_url)); ?>">
                                        <i class="fa-brands fa-x-twitter"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if( !empty(getSetting()->linkedin_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->linkedin_url)); ?>">
                                        <i class="fa-brands fa-linkedin-in"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="footer-widget widget-2">
                        <h3 class="widget-header">Course Info</h3>
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <ul class="footer-list">
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="service.html">Resource Center</a></li>
                                    <li><a href="team.html">Careers</a></li>
                                    <li><a href="contact.html">Instructor</a></li>
                                    <li><a href="contact.html">Become A Teacher</a></li>
                                </ul>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <ul class="footer-list">
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="service.html">Resource Center</a></li>
                                    <li><a href="team.html">Careers</a></li>
                                    <li><a href="contact.html">Instructor</a></li>
                                    <li><a href="contact.html">Become A Teacher</a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="footer-widget">
                        <h3 class="widget-header">Recent Post</h3>
                        <div class="sidebar-post mb-20">
                            <img src="<?php echo e(asset('frontend/assets/img/images/footer-post-1.png')); ?>" alt="post">
                            <div class="post-content">
                                <h3 class="title"><a href="#">Where Dreams Find a Home</a></h3>
                                <ul class="post-meta">
                                    <li><i class='bx bx-calendar' style="font-size: 20px;"></i>20 April, 2024</li>
                                </ul>
                            </div>
                        </div>
                        <div class="sidebar-post">
                            <img src="<?php echo e(asset('frontend/assets/img/images/footer-post-2.png')); ?>" alt="post">
                            <div class="post-content">
                                <h3 class="title"><a href="#">Where Dreams Find a Home</a></h3>
                                <ul class="post-meta">
                                    <li><i class='bx bx-calendar' style="font-size: 20px;"></i>20 April, 2024</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area">
        <div class="container">
            <div class="copyright-content">
                <p>Copyright © <u><a href="<?php echo e(url('/')); ?>"><?php echo e(getSetting()->copyright); ?></a></u>. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/footer.blade.php ENDPATH**/ ?>