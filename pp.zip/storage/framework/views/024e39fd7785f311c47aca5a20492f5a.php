
    <header class="header header-2 header-4 sticky-active">
        <div class="top-bar">
            <div class="container">
                <div class="top-bar-inner">
                    
                    <div class="top-bar-right">
                        <div class="top-social-wrap">
                            <ul class="social-list">
                                <?php if( !empty(getSetting()->facebook_url) ): ?>
                                    <li>
                                        <a href="<?php echo e(asset(getSetting()->facebook_url)); ?>">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if( !empty(getSetting()->instagram_url) ): ?>
                                    <li>
                                        <a href="<?php echo e(asset(getSetting()->instagram_url)); ?>">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if( !empty(getSetting()->twitter_url) ): ?>
                                    <li>
                                        <a href="<?php echo e(asset(getSetting()->twitter_url)); ?>">
                                            <i class="fa-brands fa-x-twitter"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if( !empty(getSetting()->linkedin_url) ): ?>
                                    <li>
                                        <a href="<?php echo e(asset(getSetting()->linkedin_url)); ?>">
                                            <i class="fa-brands fa-linkedin-in"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="register-box">
                            <div class="icon"><i class="fa-regular fa-user"></i></div>

                            <?php if( Auth::check() ): ?>
                               <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                    <button type="submit" style="color: #FFF;">
                                        <?php echo e(__('Log Out')); ?>

                                    </button>
                                </form>
                            <?php else: ?>
                              <a href="<?php echo e(route('login')); ?>">Login </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="primary-header">
            <div class="container">
                <div class="primary-header-inner">
                    <div class="header-logo d-lg-block">
                        <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset(getSetting()->logo)); ?>" alt="Logo">
                            </a>
                    </div>
                    <div class="header-right-wrap">
                        <div class="header-menu-wrap">
                            <div class="mobile-menu-items">
                                <ul class="sub-menu">
                                    <li class="active">
                                        <a href="<?php echo e(url('/')); ?>">Home</a>
                                        
                                    </li>
                                    

                                    <li>
                                        <a href="<?php echo e(route('cart')); ?>">Cart</a>
                                        
                                    </li>

                                    
                                    
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- /.header-menu-wrap -->
                        <div class="header-right">
                            

                            <div class="header-right-icon shop-btn">
                                <a href="<?php echo e(route('cart')); ?>"><i class='bx bx-cart-alt' style="font-size: 24px;"></i></a>
                                
                                <span class="number"><?php echo e(getTotalCart()); ?></span>
                            </div>

                            

                            <div class="header-logo d-none d-lg-none">
                                <a href="<?php echo e(route('home')); ?>">
                                        <img src="<?php echo e(asset(getSetting()->logo)); ?>" alt="Logo">
                                    </a>
                            </div>
                            <div class="header-right-item d-lg-none d-md-block">
                                <a href="javascript:void(0)" class="mobile-side-menu-toggle"><i class="fa-sharp fa-solid fa-bars"></i
                                    ></a>
                            </div>
                        </div>
                        <!-- /.header-right -->
                    </div>
                </div>
                <!-- /.primary-header-inner -->
            </div>
        </div>
    </header>
    <!-- /.Main Header -->

    
    <!-- /#popup-search-box -->

    <div class="mobile-side-menu">
        <div class="side-menu-content">
            <div class="side-menu-head">
                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset(getSetting()->logo)); ?>" alt="logo"></a>
                <button class="mobile-side-menu-close"><i class='bx bx-x' style="font-size: 24px;"></i></button>
            </div>
            <div class="side-menu-wrap"></div>
            <ul class="side-menu-list">
                <li>
                    <i class="fa-light fa-location-dot"></i>Address : <span><?php echo e(getSetting()->address); ?></span>
                </li>

                <li>
                    <i class="fa-light fa-phone"></i>Phone : <a href="tel:<?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?>"><?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?></a>
                </li>
    
                <li>
                    <i class="fa-light fa-envelope"></i>Email : <a href="mailto:<?php echo e(getSetting()->email ? getSetting()->email : getSetting()->email_optional); ?>"><?php echo e(getSetting()->email ? getSetting()->email : getSetting()->email_optional); ?></a></li>
            </ul>
        </div>
    </div>
    <!-- /.mobile-side-menu -->
    <div class="mobile-side-menu-overlay"></div>

<?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>